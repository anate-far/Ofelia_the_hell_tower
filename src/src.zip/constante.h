#ifndef CONSTANTE_H
#define CONSTANTE_H

//Window
#define SIZE_WINDOW_W 800
#define SIZE_WINDOW_H 600

//Player
#define PLAYER_START_POS_X 100
#define PLAYER_START_POS_Y 200
#define PLAYER_SIZE_W 32
#define PLAYER_SIZE_H 32
#define PLAYER_SPEED 3
	//animation
#define NB_IMG_ANIMATION 3
#define PLAYER_TEXTURE_UP "img/player/tile001.png" 
#define PLAYER_TEXTURE_DOWN "img/player/tile010.png"
#define PLAYER_TEXTURE_LEFT "img/player/tile007.png"
#define PLAYER_TEXTURE_RIGHT "img/player/tile004.png"
enum{
	UP = 0, DOWN = 1, LEFT = 2, RIGHT = 3
};


#endif
