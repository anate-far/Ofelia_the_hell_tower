#include <stdio.h>
#include <stdlib.h>
#include <SDL.h>

#include "player.h"
#include "tools_sdl.h"
#include "constante.h"

//builder and destructive
Player* player_create(SDL_Renderer* renderer)
{
	Player* player = malloc(sizeof(Player));
	
	//Initi renderer
	player->p_renderer =  renderer;

	//Init tab texture;
	player->up = malloc(sizeof(SDL_Texture*) * NB_IMG_ANIMATION);	
	//Init texture
	player->up[0] = create_texture(renderer, "img/player/tile001.png");
	player->up[1] = create_texture(renderer, "img/player/tile000.png");
	player->up[2] = create_texture(renderer, "img/player/tile002.png");
	//texture_display
	player->texture_display = player->up[0];	

	//init pos
	player->pos.x = PLAYER_START_POS_X;
	player->pos.y = PLAYER_START_POS_Y;
	player->pos.w = PLAYER_SIZE_W;
	player->pos.h = PLAYER_SIZE_H;

	return player;
}
void player_destroy(Player* player)
{
	//destructive texture
	for(int i = 0; i < NB_IMG_ANIMATION; i++)
		SDL_DestroyTexture(player->up[i]);
	//destructive tab
	free(player->up);

	//destructive struct player
	free(player);
}

//display
void player_display(Player* player)
{
	SDL_RenderCopy(player->p_renderer, player->texture_display, NULL, &player->pos);
}

void player_move(Player* player, int direction)
{
	if(direction == UP)
	{
		//Movement
		player->pos.y -= PLAYER_SPEED;

		//animation
	}
}
