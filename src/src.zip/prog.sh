./../bin/prog
